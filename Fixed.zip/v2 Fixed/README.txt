Hello :) 

Windows :
cd v2 && v2.py

Linux :
cd v2 && v2.py

Termux (android):
cd v2 && v2.py